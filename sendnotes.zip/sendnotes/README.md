# sendnotes

Plugin para Joomla 3.x que permite enviar emails cuando se agreguen notas a los usuarios usando los datos de envio del sistema.

Permite además enviar una copia al administrador.
